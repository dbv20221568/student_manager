// ==================== GLOBAL VARIABLES ====================
let students = JSON.parse(localStorage.getItem('students')) || [];

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    updateDashboard();
    displayStudents();
    setupEventListeners();
    setupSearchEmptyState();
    saveToLocalStorage();
}

// ==================== EVENT LISTENERS ====================
function setupEventListeners() {
    // Navigation buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const sectionId = this.getAttribute('data-section');
            showSection(sectionId, this);
        });
    });

    // Form submissions
    document.getElementById('student-form').addEventListener('submit', handleAddStudent);
    document.getElementById('edit-form').addEventListener('submit', handleEditStudent);

    // Modal controls
    document.querySelectorAll('[data-action="close-modal"]').forEach(btn => {
        btn.addEventListener('click', closeModal);
    });

    // Search functionality
    document.getElementById('search-input').addEventListener('input', handleSearch);

    // Generate ID button
    document.getElementById('generate-id-btn').addEventListener('click', function() {
        document.getElementById('student-id').value = generateStudentID();
    });

    // Report buttons
    document.querySelector('[data-action="export"]')?.addEventListener('click', exportData);
    document.querySelector('[data-action="generate-report"]')?.addEventListener('click', generateReport);
    document.getElementById('print-btn')?.addEventListener('click', printStudentList);

    // Modal close on outside click
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('edit-modal');
        if (event.target === modal) {
            closeModal();
        }
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });

    // Form validation
    setupFormValidation();
}

// ==================== NAVIGATION ====================
function showSection(sectionId, clickedBtn) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });

    // Remove active class from all nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected section
    document.getElementById(sectionId).classList.add('active');

    // Add active class to clicked nav button
    if (clickedBtn) {
        clickedBtn.classList.add('active');
    }

    // Update displays based on section
    switch(sectionId) {
        case 'view-students':
            displayStudents();
            break;
        case 'dashboard':
            updateDashboard();
            break;
        case 'reports':
            updateReports();
            break;
        case 'search-students':
            setupSearchEmptyState();
            break;
    }
}

// ==================== STUDENT MANAGEMENT ====================
function handleAddStudent(e) {
    e.preventDefault();
    
    const studentData = {
        id: document.getElementById('student-id').value.trim(),
        name: document.getElementById('full-name').value.trim(),
        email: document.getElementById('email').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        gender: document.getElementById('gender').value,
        major: document.getElementById('major').value,
        year: document.getElementById('year').value,
        address: document.getElementById('address').value.trim(),
        dateAdded: new Date().toISOString()
    };

    // Validation
    if (!validateStudentData(studentData)) {
        return;
    }

    // Check if student ID already exists
    if (students.some(student => student.id === studentData.id)) {
        showAlert('Mã sinh viên đã tồn tại!', 'error');
        return;
    }

    // Check if email already exists
    if (students.some(student => student.email === studentData.email)) {
        showAlert('Email đã tồn tại!', 'error');
        return;
    }

    students.push(studentData);
    saveToLocalStorage();
    showAlert('Thêm sinh viên thành công!', 'success');
    document.getElementById('student-form').reset();
    updateDashboard();
    displayStudents();
}

function handleEditStudent(e) {
    e.preventDefault();
    
    const index = parseInt(document.getElementById('edit-index').value);
    const studentData = {
        id: document.getElementById('edit-student-id').value.trim(),
        name: document.getElementById('edit-full-name').value.trim(),
        email: document.getElementById('edit-email').value.trim(),
        phone: document.getElementById('edit-phone').value.trim(),
        gender: document.getElementById('edit-gender').value,
        major: document.getElementById('edit-major').value,
        year: document.getElementById('edit-year').value,
        address: document.getElementById('edit-address').value.trim(),
        dateAdded: students[index].dateAdded
    };

    // Validation
    if (!validateStudentData(studentData)) {
        return;
    }

    // Check if ID exists for other students
    if (students.some((student, i) => student.id === studentData.id && i !== index)) {
        showAlert('Mã sinh viên đã tồn tại!', 'error');
        return;
    }

    // Check if email exists for other students
    if (students.some((student, i) => student.email === studentData.email && i !== index)) {
        showAlert('Email đã tồn tại!', 'error');
        return;
    }

    students[index] = studentData;
    saveToLocalStorage();
    showAlert('Cập nhật sinh viên thành công!', 'success');
    closeModal();
    updateDashboard();
    displayStudents();
}

function editStudent(index) {
    const student = students[index];
    document.getElementById('edit-index').value = index;
    document.getElementById('edit-student-id').value = student.id;
    document.getElementById('edit-full-name').value = student.name;
    document.getElementById('edit-email').value = student.email;
    document.getElementById('edit-phone').value = student.phone;
    document.getElementById('edit-gender').value = student.gender;
    document.getElementById('edit-major').value = student.major;
    document.getElementById('edit-year').value = student.year;
    document.getElementById('edit-address').value = student.address;

    document.getElementById('edit-modal').style.display = 'block';
}

function deleteStudent(index) {
    const student = students[index];
    if (confirm(`Bạn có chắc chắn muốn xóa sinh viên "${student.name}"?`)) {
        students.splice(index, 1);
        saveToLocalStorage();
        showAlert('Xóa sinh viên thành công!', 'success');
        updateDashboard();
        displayStudents();
    }
}

// ==================== DISPLAY FUNCTIONS ====================
function displayStudents() {
    const container = document.getElementById('students-list');
    container.innerHTML = '';

    if (students.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">👥</div>
                <p>Chưa có sinh viên nào. Hãy thêm sinh viên để bắt đầu!</p>
            </div>
        `;
        return;
    }

    students.forEach((student, index) => {
        const studentCard = createStudentCard(student, index);
        container.appendChild(studentCard);
    });
}

function createStudentCard(student, index) {
    const card = document.createElement('div');
    card.className = 'student-card';
    
    card.innerHTML = `
        <div class="student-name">${escapeHtml(student.name)}</div>
        <div class="student-info">
            <div class="student-info-item">
                <span class="student-info-label">Mã SV:</span>
                <span class="student-info-value">${escapeHtml(student.id)}</span>
            </div>
            <div class="student-info-item">
                <span class="student-info-label">Email:</span>
                <span class="student-info-value">${escapeHtml(student.email)}</span>
            </div>
            <div class="student-info-item">
                <span class="student-info-label">Điện thoại:</span>
                <span class="student-info-value">${escapeHtml(student.phone)}</span>
            </div>
            <div class="student-info-item">
                <span class="student-info-label">Giới tính:</span>
                <span class="student-info-value">${escapeHtml(student.gender)}</span>
            </div>
            <div class="student-info-item">
                <span class="student-info-label">Ngành:</span>
                <span class="student-info-value">${escapeHtml(student.major)}</span>
            </div>
            <div class="student-info-item">
                <span class="student-info-label">Năm:</span>
                <span class="student-info-value">Năm ${escapeHtml(student.year)}</span>
            </div>
            <div class="student-info-item">
                <span class="student-info-label">Địa chỉ:</span>
                <span class="student-info-value">${escapeHtml(student.address)}</span>
            </div>
        </div>
        <div class="card-actions">
            <button class="btn btn-success btn-edit" data-index="${index}">
                <span class="btn-icon">✏️</span>
                Sửa
            </button>
            <button class="btn btn-danger btn-delete" data-index="${index}">
                <span class="btn-icon">🗑️</span>
                Xóa
            </button>
        </div>
    `;

    // Add event listeners
    card.querySelector('.btn-edit').addEventListener('click', () => editStudent(index));
    card.querySelector('.btn-delete').addEventListener('click', () => deleteStudent(index));

    return card;
}

// ==================== SEARCH FUNCTIONALITY ====================
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase().trim();
    const searchResults = document.getElementById('search-results');

    if (searchTerm === '') {
        setupSearchEmptyState();
        return;
    }

    const filteredStudents = students.filter(student => 
        student.name.toLowerCase().includes(searchTerm) ||
        student.id.toLowerCase().includes(searchTerm) ||
        student.email.toLowerCase().includes(searchTerm) ||
        student.major.toLowerCase().includes(searchTerm) ||
        student.address.toLowerCase().includes(searchTerm) ||
        student.phone.includes(searchTerm)
    );

    searchResults.innerHTML = '';

    if (filteredStudents.length === 0) {
        searchResults.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <p>Không tìm thấy sinh viên nào phù hợp với từ khóa "${escapeHtml(searchTerm)}"</p>
            </div>
        `;
        return;
    }

    filteredStudents.forEach((student) => {
        const originalIndex = students.findIndex(s => s.id === student.id);
        const studentCard = createStudentCard(student, originalIndex);
        searchResults.appendChild(studentCard);
    });
}

function setupSearchEmptyState() {
    const searchResults = document.getElementById('search-results');
    searchResults.innerHTML = `
        <div class="empty-state">
            <div class="empty-state-icon">🔍</div>
            <p>Nhập từ khóa để tìm kiếm sinh viên</p>
        </div>
    `;
}

// ==================== DASHBOARD & STATISTICS ====================
function updateDashboard() {
    const totalStudents = students.length;
    const maleStudents = students.filter(s => s.gender === 'Nam').length;
    const femaleStudents = students.filter(s => s.gender === 'Nữ').length;

    document.getElementById('total-students').textContent = totalStudents;
    document.getElementById('male-students').textContent = maleStudents;
    document.getElementById('female-students').textContent = femaleStudents;

    // Display recent students
    displayRecentStudents();
}

function displayRecentStudents() {
    const recentContainer = document.getElementById('recent-students');
    
    if (students.length === 0) {
        recentContainer.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">📚</div>
                <h3 style="margin-bottom: 1rem; color: #6b7280;">Chưa có sinh viên nào</h3>
                <p>Hãy thêm sinh viên đầu tiên để bắt đầu sử dụng hệ thống!</p>
                <button class="btn btn-primary" onclick="showSection('add-student', document.querySelector('[data-section=\\'add-student\\']'))" style="margin-top: 1rem;">
                    <span class="btn-icon">➕</span>
                    Thêm sinh viên đầu tiên
                </button>
            </div>
        `;
        return;
    }
    
    const recentStudents = students.slice(-3).reverse();
    recentContainer.innerHTML = '<h3 style="margin-top: 2rem; margin-bottom: 1rem; font-size: 1.25rem; font-weight: 600;">Sinh viên mới nhất</h3>';
    const recentGrid = document.createElement('div');
    recentGrid.className = 'students-grid';

    recentStudents.forEach((student) => {
        const originalIndex = students.findIndex(s => s.id === student.id);
        const studentCard = createStudentCard(student, originalIndex);
        recentGrid.appendChild(studentCard);
    });

    recentContainer.appendChild(recentGrid);
}

function updateReports() {
    const itStudents = students.filter(s => s.major === 'Công nghệ thông tin').length;
    const csStudents = students.filter(s => s.major === 'Khoa học máy tính').length;
    const seStudents = students.filter(s => s.major === 'Kỹ thuật phần mềm').length;
    const businessStudents = students.filter(s => s.major === 'Quản trị kinh doanh').length;

    document.getElementById('it-students').textContent = itStudents;
    document.getElementById('cs-students').textContent = csStudents;
    document.getElementById('se-students').textContent = seStudents;
    document.getElementById('business-students').textContent = businessStudents;
}

// ==================== UTILITY FUNCTIONS ====================
function generateStudentID() {
    const year = new Date().getFullYear().toString().slice(-2);
    const sequence = (students.length + 1).toString().padStart(3, '0');
    return `SV${year}${sequence}`;
}

function validateStudentData(data) {
    const errors = [];

    if (!data.id) errors.push('Mã sinh viên không được để trống');
    if (!data.name) errors.push('Họ tên không được để trống');
    if (!data.email) errors.push('Email không được để trống');
    if (!data.phone) errors.push('Số điện thoại không được để trống');
    if (!data.gender) errors.push('Giới tính không được để trống');
    if (!data.major) errors.push('Ngành học không được để trống');
    if (!data.year) errors.push('Năm học không được để trống');
    if (!data.address) errors.push('Địa chỉ không được để trống');

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (data.email && !emailRegex.test(data.email)) {
        errors.push('Email không hợp lệ');
    }

    // Phone validation
    const phoneRegex = /^[0-9]{10,11}$/;
    if (data.phone && !phoneRegex.test(data.phone.replace(/\s+/g, ''))) {
        errors.push('Số điện thoại không hợp lệ (10-11 số)');
    }

    if (errors.length > 0) {
        showAlert(errors.join(', '), 'error');
        return false;
    }

    return true;
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

function saveToLocalStorage() {
    try {
        localStorage.setItem('students', JSON.stringify(students));
    } catch (error) {
        console.error('Không thể lưu dữ liệu:', error);
        showAlert('Không thể lưu dữ liệu!', 'error');
    }
}

// ==================== MODAL FUNCTIONS ====================
function closeModal() {
    document.getElementById('edit-modal').style.display = 'none';
}

// ==================== EXPORT & PRINT FUNCTIONS ====================
function exportData() {
    if (students.length === 0) {
        showAlert('Không có dữ liệu để xuất!', 'error');
        return;
    }

    try {
        const csvContent = "data:text/csv;charset=utf-8,\uFEFF" 
            + "Mã sinh viên,Họ tên,Email,Điện thoại,Giới tính,Ngành học,Năm học,Địa chỉ\n"
            + students.map(s => 
                `"${s.id}","${s.name}","${s.email}","${s.phone}","${s.gender}","${s.major}","Năm ${s.year}","${s.address}"`
            ).join("\n");

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `danh_sach_sinh_vien_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        showAlert('Xuất dữ liệu thành công!', 'success');
    } catch (error) {
        console.error('Lỗi xuất dữ liệu:', error);
        showAlert('Không thể xuất dữ liệu!', 'error');
    }
}

function generateReport() {
    if (students.length === 0) {
        showAlert('Không có dữ liệu để tạo báo cáo!', 'error');
        return;
    }

    try {
        const totalStudents = students.length;
        const maleStudents = students.filter(s => s.gender === 'Nam').length;
        const femaleStudents = students.filter(s => s.gender === 'Nữ').length;
        const itStudents = students.filter(s => s.major === 'Công nghệ thông tin').length;
        const csStudents = students.filter(s => s.major === 'Khoa học máy tính').length;
        const seStudents = students.filter(s => s.major === 'Kỹ thuật phần mềm').length;
        const businessStudents = students.filter(s => s.major === 'Quản trị kinh doanh').length;
        const marketingStudents = students.filter(s => s.major === 'Marketing').length;

        const report = `
BÁO CÁO HỆ THỐNG QUẢN LÝ SINH VIÊN
=====================================

Ngày tạo: ${new Date().toLocaleDateString('vi-VN')}
Thời gian: ${new Date().toLocaleTimeString('vi-VN')}

TỔNG QUAN:
-----------
Tổng số sinh viên: ${totalStudents}
Sinh viên nam: ${maleStudents} (${totalStudents > 0 ? ((maleStudents/totalStudents)*100).toFixed(1) : 0}%)
Sinh viên nữ: ${femaleStudents} (${totalStudents > 0 ? ((femaleStudents/totalStudents)*100).toFixed(1) : 0}%)

THỐNG KÊ THEO NGÀNH HỌC:
------------------------
Công nghệ thông tin: ${itStudents} sinh viên (${totalStudents > 0 ? ((itStudents/totalStudents)*100).toFixed(1) : 0}%)
Khoa học máy tính: ${csStudents} sinh viên (${totalStudents > 0 ? ((csStudents/totalStudents)*100).toFixed(1) : 0}%)
Kỹ thuật phần mềm: ${seStudents} sinh viên (${totalStudents > 0 ? ((seStudents/totalStudents)*100).toFixed(1) : 0}%)
Quản trị kinh doanh: ${businessStudents} sinh viên (${totalStudents > 0 ? ((businessStudents/totalStudents)*100).toFixed(1) : 0}%)
Marketing: ${marketingStudents} sinh viên (${totalStudents > 0 ? ((marketingStudents/totalStudents)*100).toFixed(1) : 0}%)

THỐNG KÊ THEO NĂM HỌC:
----------------------
Năm 1: ${students.filter(s => s.year === '1').length} sinh viên
Năm 2: ${students.filter(s => s.year === '2').length} sinh viên
Năm 3: ${students.filter(s => s.year === '3').length} sinh viên
Năm 4: ${students.filter(s => s.year === '4').length} sinh viên

DANH SÁCH SINH VIÊN MỚI NHẤT (5 người):
---------------------------------------
${students.slice(-5).reverse().map((s, index) => 
    `${index + 1}. ${s.name} (${s.id}) - ${s.major} - Năm ${s.year}`
).join('\n')}

DANH SÁCH TẤT CẢ SINH VIÊN:
---------------------------
${students.map((s, index) => 
    `${index + 1}. ${s.name} (${s.id}) - ${s.email} - ${s.phone} - ${s.major} - Năm ${s.year}`
).join('\n')}

---
Báo cáo được tạo tự động bởi Hệ Thống Quản Lý Sinh Viên
        `;

        const element = document.createElement('a');
        const file = new Blob([report], {type: 'text/plain;charset=utf-8'});
        element.href = URL.createObjectURL(file);
        element.download = `bao_cao_sinh_vien_${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);

        showAlert('Tạo báo cáo thành công!', 'success');
    } catch (error) {
        console.error('Lỗi tạo báo cáo:', error);
        showAlert('Không thể tạo báo cáo!', 'error');
    }
}

function printStudentList() {
    if (students.length === 0) {
        showAlert('Không có dữ liệu để in!', 'error');
        return;
    }

    try {
        const printWindow = window.open('', '_blank');
        const studentsList = students.map((student, index) => `
            <tr>
                <td>${index + 1}</td>
                <td>${escapeHtml(student.id)}</td>
                <td>${escapeHtml(student.name)}</td>
                <td>${escapeHtml(student.email)}</td>
                <td>${escapeHtml(student.phone)}</td>
                <td>${escapeHtml(student.gender)}</td>
                <td>${escapeHtml(student.major)}</td>
                <td>Năm ${escapeHtml(student.year)}</td>
            </tr>
        `).join('');

        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Danh sách sinh viên</title>
                <meta charset="UTF-8">
                <style>
                    body { 
                        font-family: 'Times New Roman', serif; 
                        margin: 20px; 
                        font-size: 14px;
                        line-height: 1.4;
                    }
                    .header {
                        text-align: center;
                        margin-bottom: 30px;
                        border-bottom: 2px solid #333;
                        padding-bottom: 20px;
                    }
                    h1 { 
                        color: #333; 
                        margin-bottom: 10px;
                        font-size: 24px;
                        font-weight: bold;
                    }
                    h2 {
                        color: #666;
                        margin-bottom: 20px;
                        font-size: 18px;
                    }
                    .info {
                        display: flex;
                        justify-content: space-between;
                        margin-bottom: 20px;
                        font-weight: bold;
                    }
                    table { 
                        width: 100%; 
                        border-collapse: collapse; 
                        margin-top: 20px; 
                        font-size: 12px;
                    }
                    th, td { 
                        border: 1px solid #333; 
                        padding: 8px; 
                        text-align: left; 
                    }
                    th { 
                        background-color: #f0f0f0; 
                        font-weight: bold;
                        text-align: center;
                    }
                    tbody tr:nth-child(even) {
                        background-color: #f9f9f9;
                    }
                    .footer {
                        margin-top: 30px;
                        text-align: center;
                        font-style: italic;
                        color: #666;
                    }
                    @media print {
                        body { margin: 0; }
                        .header { break-after: avoid; }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>HỆ THỐNG QUẢN LÝ SINH VIÊN</h1>
                    <h2>DANH SÁCH SINH VIÊN</h2>
                </div>
                <div class="info">
                    <span>Ngày in: ${new Date().toLocaleDateString('vi-VN')}</span>
                    <span>Tổng số: ${students.length} sinh viên</span>
                    <span>Thời gian: ${new Date().toLocaleTimeString('vi-VN')}</span>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th style="width: 40px;">STT</th>
                            <th style="width: 80px;">Mã SV</th>
                            <th style="width: 150px;">Họ và tên</th>
                            <th style="width: 120px;">Email</th>
                            <th style="width: 90px;">Điện thoại</th>
                            <th style="width: 60px;">Giới tính</th>
                            <th style="width: 120px;">Ngành học</th>
                            <th style="width: 60px;">Năm</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${studentsList}
                    </tbody>
                </table>
                <div class="footer">
                    <p>Báo cáo được tạo tự động bởi Hệ Thống Quản Lý Sinh Viên</p>
                </div>
            </body>
            </html>
        `);
        
        printWindow.document.close();
        printWindow.focus();
        
        // Wait for content to load before printing
        setTimeout(() => {
            printWindow.print();
        }, 500);
        
        showAlert('Chuẩn bị in danh sách...', 'success');
    } catch (error) {
        console.error('Lỗi in ấn:', error);
        showAlert('Không thể in danh sách!', 'error');
    }
}

// ==================== FORM VALIDATION ====================
function setupFormValidation() {
    // Real-time email validation
    document.querySelectorAll('input[type="email"]').forEach(input => {
        input.addEventListener('blur', function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (this.value && !emailRegex.test(this.value)) {
                this.style.borderColor = '#ef4444';
                showAlert('Email không hợp lệ!', 'error');
            } else {
                this.style.borderColor = '#d1d5db';
            }
        });
    });

    // Real-time phone validation
    document.querySelectorAll('input[type="tel"]').forEach(input => {
        input.addEventListener('blur', function() {
            const phoneRegex = /^[0-9]{10,11}$/;
            if (this.value && !phoneRegex.test(this.value.replace(/\s+/g, ''))) {
                this.style.borderColor = '#ef4444';
                showAlert('Số điện thoại không hợp lệ (10-11 số)!', 'error');
            } else {
                this.style.borderColor = '#d1d5db';
            }
        });
        
        // Only allow numbers and spaces
        input.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9\s]/g, '');
        });
    });

    // Student ID validation
    document.querySelectorAll('#student-id, #edit-student-id').forEach(input => {
        input.addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
    });

    // Name validation - only letters and spaces
    document.querySelectorAll('#full-name, #edit-full-name').forEach(input => {
        input.addEventListener('input', function() {
            // Allow Vietnamese characters
            this.value = this.value.replace(/[^a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂÁÀẢÃẠẮẰẲẴẶẤẦẨẪẬÉÈẺẼẸẾỀỂỄỆÓÒỎÕỌỐỒỔỖỘỚỜỞỠỢÚÙỦŨỤỨỪỬỮỰÍÌỈĨỊĐĂÂÔƠƯưăâôơưáàảãạắằẳẵặấầẩẫậéèẻẽẹếềểễệóòỏõọốồổỗộớờởỡợúùủũụứừửữựíìỉĩịđ\s]/g, '');
        });
    });
}

// ==================== ALERT SYSTEM ====================
function showAlert(message, type) {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());

    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;

    const activeSection = document.querySelector('.section.active');
    if (activeSection) {
        activeSection.insertBefore(alert, activeSection.firstChild);
        
        // Auto remove alert after 4 seconds
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 4000);
    }
}

// ==================== ADDITIONAL UTILITY FUNCTIONS ====================
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN');
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    return `${date.toLocaleDateString('vi-VN')} ${date.toLocaleTimeString('vi-VN')}`;
}

function getStudentsByMajor(major) {
    return students.filter(student => student.major === major);
}

function getStudentsByYear(year) {
    return students.filter(student => student.year === year);
}

function getStudentsByGender(gender) {
    return students.filter(student => student.gender === gender);
}

// ==================== BACKUP & RESTORE FUNCTIONS ====================
function backupData() {
    try {
        const backup = {
            students: students,
            timestamp: new Date().toISOString(),
            version: '1.0'
        };
        
        const dataStr = JSON.stringify(backup, null, 2);
        const dataBlob = new Blob([dataStr], {type: 'application/json'});
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = `backup_sinh_vien_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showAlert('Sao lưu dữ liệu thành công!', 'success');
    } catch (error) {
        console.error('Lỗi sao lưu:', error);
        showAlert('Không thể sao lưu dữ liệu!', 'error');
    }
}

function restoreData(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const backup = JSON.parse(e.target.result);
            if (backup.students && Array.isArray(backup.students)) {
                if (confirm('Bạn có chắc chắn muốn khôi phục dữ liệu? Dữ liệu hiện tại sẽ bị ghi đè!')) {
                    students = backup.students;
                    saveToLocalStorage();
                    updateDashboard();
                    displayStudents();
                    showAlert('Khôi phục dữ liệu thành công!', 'success');
                }
            } else {
                showAlert('File backup không hợp lệ!', 'error');
            }
        } catch (error) {
            console.error('Lỗi khôi phục:', error);
            showAlert('Không thể đọc file backup!', 'error');
        }
    };
    reader.readAsText(file);
}

// ==================== KEYBOARD SHORTCUTS ====================
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + S: Save (prevent default and show save message)
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            saveToLocalStorage();
            showAlert('Dữ liệu đã được lưu!', 'success');
        }
        
        // Ctrl/Cmd + N: Add new student
        if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
            e.preventDefault();
            showSection('add-student', document.querySelector('[data-section="add-student"]'));
        }
        
        // Ctrl/Cmd + F: Focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
            e.preventDefault();
            showSection('search-students', document.querySelector('[data-section="search-students"]'));
            setTimeout(() => {
                document.getElementById('search-input').focus();
            }, 100);
        }
        
        // ESC: Close modal
        if (e.key === 'Escape') {
            closeModal();
        }
    });
}

// ==================== ADVANCED SEARCH ====================
function setupAdvancedSearch() {
    const searchInput = document.getElementById('search-input');
    let searchTimeout;
    
    searchInput.addEventListener('input', function(e) {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            handleSearch(e);
        }, 300); // Debounce search for better performance
    });
}

// ==================== DATA VALIDATION ====================
function validateAllData() {
    const invalidStudents = [];
    students.forEach((student, index) => {
        if (!validateStudentData(student, false)) {
            invalidStudents.push({index, student});
        }
    });
    
    if (invalidStudents.length > 0) {
        console.warn('Found invalid student data:', invalidStudents);
        return false;
    }
    return true;
}

function validateStudentData(data, showErrors = true) {
    const errors = [];

    if (!data.id || data.id.trim() === '') errors.push('Mã sinh viên không được để trống');
    if (!data.name || data.name.trim() === '') errors.push('Họ tên không được để trống');
    if (!data.email || data.email.trim() === '') errors.push('Email không được để trống');
    if (!data.phone || data.phone.trim() === '') errors.push('Số điện thoại không được để trống');
    if (!data.gender) errors.push('Giới tính không được để trống');
    if (!data.major) errors.push('Ngành học không được để trống');
    if (!data.year) errors.push('Năm học không được để trống');
    if (!data.address || data.address.trim() === '') errors.push('Địa chỉ không được để trống');

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (data.email && !emailRegex.test(data.email)) {
        errors.push('Email không hợp lệ');
    }

    // Phone validation
    const phoneRegex = /^[0-9]{10,11}$/;
    if (data.phone && !phoneRegex.test(data.phone.replace(/\s+/g, ''))) {
        errors.push('Số điện thoại không hợp lệ (10-11 số)');
    }

    // Student ID format validation
    if (data.id && !/^[A-Z0-9]+$/.test(data.id)) {
        errors.push('Mã sinh viên chỉ được chứa chữ cái viết hoa và số');
    }

    if (errors.length > 0 && showErrors) {
        showAlert(errors.join(', '), 'error');
        return false;
    }

    return errors.length === 0;
}

// ==================== STATISTICS & ANALYTICS ====================
function getDetailedStatistics() {
    const stats = {
        total: students.length,
        byGender: {
            male: students.filter(s => s.gender === 'Nam').length,
            female: students.filter(s => s.gender === 'Nữ').length
        },
        byMajor: {},
        byYear: {},
        recentAdditions: students.filter(s => {
            const addedDate = new Date(s.dateAdded);
            const now = new Date();
            const diffTime = Math.abs(now - addedDate);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            return diffDays <= 7; // Last 7 days
        }).length
    };

    // Count by major
    const majors = ['Công nghệ thông tin', 'Khoa học máy tính', 'Kỹ thuật phần mềm', 'Quản trị kinh doanh', 'Marketing'];
    majors.forEach(major => {
        stats.byMajor[major] = students.filter(s => s.major === major).length;
    });

    // Count by year
    ['1', '2', '3', '4'].forEach(year => {
        stats.byYear[year] = students.filter(s => s.year === year).length;
    });

    return stats;
}

// ==================== THEME SUPPORT ====================
function toggleTheme() {
    const body = document.body;
    const isDark = body.classList.contains('dark-theme');
    
    if (isDark) {
        body.classList.remove('dark-theme');
        localStorage.setItem('theme', 'light');
    } else {
        body.classList.add('dark-theme');
        localStorage.setItem('theme', 'dark');
    }
}

function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
    }
}

// ==================== INITIALIZATION WITH ERROR HANDLING ====================
function initializeAppWithErrorHandling() {
    try {
        // Load theme first
        loadTheme();
        
        // Setup keyboard shortcuts
        setupKeyboardShortcuts();
        
        // Setup advanced search
        setupAdvancedSearch();
        
        // Validate existing data
        if (!validateAllData()) {
            console.warn('Some student data is invalid');
        }
        
        // Initialize main app
        updateDashboard();
        displayStudents();
        setupEventListeners();
        setupSearchEmptyState();
        
        console.log('App initialized successfully');
    } catch (error) {
        console.error('Error initializing app:', error);
        showAlert('Có lỗi xảy ra khi khởi tạo ứng dụng!', 'error');
    }
}

// ==================== PERFORMANCE OPTIMIZATION ====================
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Optimized search with debouncing
const debouncedSearch = debounce(handleSearch, 300);

// ==================== ERROR BOUNDARY ====================
window.addEventListener('error', function(e) {
    console.error('Global error:', e.error);
    showAlert('Đã xảy ra lỗi không mong muốn!', 'error');
});

window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
    showAlert('Đã xảy ra lỗi xử lý dữ liệu!', 'error');
});

// ==================== FINAL INITIALIZATION ====================
// Override the original initialization with enhanced version
document.addEventListener('DOMContentLoaded', function() {
    initializeAppWithErrorHandling();
});

// ==================== EXPORT FOR TESTING ====================
// Make functions available globally for testing
window.StudentManager = {
    students,
    addStudent: handleAddStudent,
    editStudent,
    deleteStudent,
    searchStudents: handleSearch,
    exportData,
    generateReport,
    printStudentList,
    validateStudentData,
    getDetailedStatistics,
    saveToLocalStorage,
    backupData,
    restoreData
};